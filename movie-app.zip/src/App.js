import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./home";
import Watchlist from "./watchlist";
import Likes from "./likes";
import Movies from "./movies";
import Actors from "./actors";
import Navbar from "./components/Navbar";
import MovieDetail from "./components/MovieDetail";

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/movies" element={<Movies />} />
        <Route path="/watchlist" element={<Watchlist />} />
        <Route path="/likes" element={<Likes />} />
        <Route path="/actors" element={<Actors />} />
        <Route path="/movie/:id" element={<MovieDetail />} />{" "}
      </Routes>
    </Router>
  );
}

export default App;
