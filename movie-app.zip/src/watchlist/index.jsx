import React, { useState, useEffect } from "react";
import { Container, Typography, Grid } from "@mui/material";
import Cart from "../components/Card";

export default function Watchlist() {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    const fetchMovies = async () => {
      const movieTitles = Object.keys(localStorage)
        .filter(
          (key) =>
            key.includes("-watch") && JSON.parse(localStorage.getItem(key))
        )
        .map((key) => key.replace("-watch", ""));

      const apiKey = "9c90f1e68108bfcbd11e4f6c7d7cfaa4";
      const movieData = [];

      for (const title of movieTitles) {
        const response = await fetch(
          `https://api.themoviedb.org/3/search/movie?api_key=${apiKey}&query=${title}`
        );
        const data = await response.json();
        if (data.results && data.results.length > 0) {
          const movie = data.results[0];
          movieData.push(movie);
        }
      }

      setMovies(movieData);
    };

    fetchMovies();
  }, []);

  return (
    <Container>
      <Typography
        variant="h3"
        sx={{ marginBottom: 5, marginTop: 3, marginLeft: 50 }}
      >
        Watch List
      </Typography>
      {movies.length === 0 ? (
        <Typography>Henüz bir şey eklemediniz.</Typography>
      ) : (
        <Grid container spacing={2}>
          {movies
            .filter((movie) => movie.poster_path)
            .map((movie, index) => (
              <Grid item xs={12} sm={6} md={4} lg={3} key={index}>
                <Cart text={movie.title} image={movie.poster_path} />
              </Grid>
            ))}
        </Grid>
      )}
    </Container>
  );
}
