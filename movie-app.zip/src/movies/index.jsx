import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Container,
  Grid,
  CircularProgress,
  Box,
  Typography,
} from "@mui/material";
import { Link } from "react-router-dom";
import Cart from "../components/Card";

const Movies = () => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const response = await axios.get(
          "https://api.themoviedb.org/3/movie/popular?api_key=9c90f1e68108bfcbd11e4f6c7d7cfaa4&language=en-US&page=1"
        );
        setMovies(response.data.results);
        setLoading(false);
      } catch (err) {
        setError("An error occurred while fetching the movies.");
        setLoading(false);
      }
    };

    fetchMovies();
  }, []);

  if (loading) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "100vh",
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Typography variant="h6" color="error" align="center">
        {error}
      </Typography>
    );
  }

  return (
    <Container>
      <Typography
        variant="h3"
        component="h1"
        gutterBottom
        align="center"
        sx={{ marginTop: "50px", paddingTop: "32px" }}
      >
        Popular Movies
      </Typography>
      <Grid container spacing={4} sx={{ marginTop: "10px" }}>
        {movies.map((movie) => (
          <Grid item xs={12} sm={6} md={3} key={movie.id}>
            <Link to={`/movie/${movie.id}`}>
              {" "}
              <Cart image={movie.poster_path} text={movie.title} />
            </Link>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default Movies;
