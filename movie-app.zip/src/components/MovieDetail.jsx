import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import {
  Container,
  Box,
  Typography,
  CardMedia,
  Card,
  CardContent,
  Grid,
  Button,
  Avatar,
} from "@mui/material";

const MovieDetail = () => {
  const { id } = useParams();
  const [movie, setMovie] = useState(null);
  const [cast, setCast] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchMovieDetails = async () => {
      try {
        const movieResponse = await axios.get(
          `https://api.themoviedb.org/3/movie/${id}?api_key=9c90f1e68108bfcbd11e4f6c7d7cfaa4&language=en-US`
        );
        const castResponse = await axios.get(
          `https://api.themoviedb.org/3/movie/${id}/credits?api_key=9c90f1e68108bfcbd11e4f6c7d7cfaa4`
        );
        setMovie(movieResponse.data);
        setCast(castResponse.data.cast);
        setLoading(false);
      } catch (err) {
        setError("An error occurred while fetching the movie details.");
        setLoading(false);
      }
    };

    fetchMovieDetails();
  }, [id]);

  if (loading) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "100vh",
        }}
      ></Box>
    );
  }

  if (error) {
    return (
      <Typography
        variant="h6"
        color="error"
        align="center"
        sx={{ marginTop: 3 }}
      >
        {error}
      </Typography>
    );
  }

  if (!movie) return null;

  const posterUrl = movie.poster_path
    ? `https://image.tmdb.org/t/p/w500${movie.poster_path}`
    : "https://via.placeholder.com/500x750?text=No+Image+Available";

  const runtime = movie.runtime
    ? `${Math.floor(movie.runtime / 60)}h ${movie.runtime % 60}m`
    : "N/A";

  const userScore = movie.vote_average
    ? `${(movie.vote_average * 10).toFixed(0)}%`
    : "N/A";

  return (
    <Container sx={{ paddingTop: 6, paddingBottom: 4 }}>
      <Card
        sx={{
          display: "flex",
          flexDirection: { xs: "column", sm: "row" },
          boxShadow: 3,
          borderRadius: 3,
          overflow: "hidden",
          backgroundColor: "#f5f5f5",
          maxWidth: "1000px",
          margin: "auto",
          height: "auto",
          transition: "transform 0.3s ease-in-out",
          "&:hover": {
            transform: "scale(1.03)",
          },
        }}
      >
        <CardMedia
          component="img"
          alt={movie.title}
          height="600"
          image={posterUrl}
          title={movie.title}
          sx={{
            width: { xs: "100%", sm: "40%" },
            objectFit: "cover",
            borderRadius: 1,
          }}
        />
        <CardContent sx={{ flex: 1, padding: 4 }}>
          <Typography
            variant="h3"
            component="h1"
            sx={{ marginBottom: 2 }}
            color="primary"
          >
            {movie.title}
          </Typography>
          <Typography variant="h6" component="h2" color="text.primary">
            Release Date: {movie.release_date}
          </Typography>
          <Typography
            variant="body1"
            sx={{ marginTop: 2 }}
            color="text.primary"
          >
            {movie.overview}
          </Typography>
          <Grid container spacing={2} sx={{ marginTop: 2 }}>
            <Grid item xs={6}>
              <Typography variant="body2" color="text.primary">
                <strong>Runtime:</strong> {runtime}
              </Typography>
            </Grid>
            <Grid item xs={7}>
              <Typography variant="body2" color="text.primary">
                <strong>User Score:</strong> {userScore}
              </Typography>
            </Grid>
          </Grid>
          <Box sx={{ marginTop: 3.5 }}>
            <Button
              variant="contained"
              color="secondary"
              sx={{ padding: "8px 10px", borderRadius: 5 }}
            >
              Watch Now
            </Button>
          </Box>
        </CardContent>
      </Card>
      <Box sx={{ marginTop: 4 }}>
        <Typography variant="h5" component="h2" sx={{ marginBottom: 2 }}>
          Cast
        </Typography>
        <Grid container spacing={2}>
          {cast.slice(0, 12).map((actor) => (
            <Grid item xs={6} sm={4} md={2} key={actor.id}>
              <Box
                sx={{
                  textAlign: "center",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
              >
                <Avatar
                  src={`https://image.tmdb.org/t/p/w500${actor.profile_path}`}
                  alt={actor.name}
                  sx={{
                    width: 100,
                    height: 100,
                    marginBottom: 1,
                    borderRadius: "50%",
                    boxShadow: 3,
                  }}
                />
                <Typography
                  variant="body2"
                  color="text.primary"
                  sx={{ marginTop: 1 }}
                >
                  {actor.name}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {actor.character}
                </Typography>
              </Box>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Container>
  );
};

export default MovieDetail;
