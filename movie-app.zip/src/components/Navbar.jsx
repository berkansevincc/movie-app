import React, { useState } from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  TextField,
  Button,
  Box,
} from "@mui/material";
import { Outlet, useNavigate } from "react-router";

export default function Navbar() {
  const [search, setSearch] = useState("");
  console.log(search);
  const navigate = useNavigate();

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar
        position="fixed"
        sx={{
          backgroundColor: "black",
          top: 0,
          zIndex: 1100,
          width: "100%",
        }}
      >
        <Toolbar
          sx={{
            display: "flex",
            width: "100%",
            alignItems: "center",
            gap: "16px",
          }}
        >
          <Typography
            variant="h6"
            onClick={() => navigate("/")}
            style={{ cursor: "pointer" }}
          >
            Popcorn Time
          </Typography>

          <Box sx={{ flex: 1 }}>
            <Button color="inherit" onClick={() => navigate("/movies")}>
              Movies
            </Button>
            <Button color="inherit" onClick={() => navigate("/watchlist")}>
              Watchlist
            </Button>
            <Button color="inherit" onClick={() => navigate("/actors")}>
              Actors
            </Button>
            <Button color="inherit" onClick={() => navigate("/likes")}>
              Likes
            </Button>
          </Box>
          <Box>
            <TextField
              variant="outlined"
              size="small"
              placeholder="Search movies..."
              onChange={(e) => setSearch(e.target.value)}
              sx={{
                marginRight: "32px",
                background: "white",
                borderRadius: "20px",
              }}
            />
          </Box>
        </Toolbar>
      </AppBar>
      <Box sx={{ marginTop: "96px" }}>
        <Outlet />
      </Box>
    </Box>
  );
}
