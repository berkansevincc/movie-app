import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardMedia,
  Typography,
  IconButton,
  Button,
} from "@mui/material";
import { Favorite, FavoriteBorder } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";

export default function Cart({ text, image }) {
  const [isInWatchlist, setIsInWatchlist] = useState(() => {
    return JSON.parse(localStorage.getItem(text)) || false;
  });

  const [isAddedToWatch, setIsAddedToWatch] = useState(() => {
    return JSON.parse(localStorage.getItem(`${text}-watch`)) || false;
  });

  const navigate = useNavigate();

  useEffect(() => {
    localStorage.setItem(text, JSON.stringify(isInWatchlist));
  }, [isInWatchlist, text]);

  useEffect(() => {
    localStorage.setItem(`${text}-watch`, JSON.stringify(isAddedToWatch));
  }, [isAddedToWatch, text]);

  const toggleWatchlist = () => {
    const newWatchlistStatus = !isInWatchlist;
    setIsInWatchlist(newWatchlistStatus);

    if (newWatchlistStatus) {
      const likedProducts =
        JSON.parse(localStorage.getItem("likedProducts")) || [];
      const newProduct = { text, image };
      likedProducts.push(newProduct);
      localStorage.setItem("likedProducts", JSON.stringify(likedProducts));
    } else {
      const likedProducts =
        JSON.parse(localStorage.getItem("likedProducts")) || [];
      const updatedProducts = likedProducts.filter(
        (item) => item.text !== text
      );
      localStorage.setItem("likedProducts", JSON.stringify(updatedProducts));
    }
  };

  const toggleAddedToWatch = (e) => {
    e.preventDefault();
    setIsAddedToWatch(!isAddedToWatch);
  };

  const handleImageClick = () => {
    navigate(`/details/${text}`);
  };

  return (
    <Card sx={{ maxWidth: 345, position: "relative" }}>
      <CardMedia
        component="img"
        height="400"
        image={`https://image.tmdb.org/t/p/w500${image}`}
        alt={text}
        onClick={handleImageClick}
      />
      <IconButton
        onClick={toggleWatchlist}
        sx={{ position: "absolute", top: 10, right: 10, color: "white" }}
      >
        {isInWatchlist ? <Favorite color="error" /> : <FavoriteBorder />}
      </IconButton>
      <CardContent>
        <Typography variant="h6">{text}</Typography>
        <Button
          variant={isAddedToWatch ? "contained" : "outlined"}
          color="black"
          onClick={toggleAddedToWatch}
          sx={{ marginTop: 3 }}
        >
          {isAddedToWatch ? "on watchlist" : "add watchlist"}
        </Button>
      </CardContent>
    </Card>
  );
}
