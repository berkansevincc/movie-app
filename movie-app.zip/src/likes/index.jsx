import React, { useEffect, useState } from "react";
import { Container, Typography, Grid } from "@mui/material";
import Cart from "../components/Card";

export default function Likes() {
  const [likedProducts, setLikedProducts] = useState([]);

  useEffect(() => {
    const storedLikedProducts =
      JSON.parse(localStorage.getItem("likedProducts")) || [];
    setLikedProducts(storedLikedProducts);
  }, []);

  return (
    <Container>
      <Typography
        variant="h3"
        sx={{ marginBottom: 5, marginTop: 3, marginLeft: 60 }}
      >
        Likes
      </Typography>
      {likedProducts.length === 0 ? (
        <Typography>Henüz beğenilen ürün yok.</Typography>
      ) : (
        <Grid container spacing={2}>
          {likedProducts
            .filter((product) => product.image)
            .map((product, index) => (
              <Grid item xs={12} sm={6} md={4} lg={3} key={index}>
                <Cart text={product.text} image={product.image} />
              </Grid>
            ))}
        </Grid>
      )}
    </Container>
  );
}
