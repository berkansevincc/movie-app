import React, { useEffect, useState } from "react";
import { Container, Grid, Typography } from "@mui/material";
import Cart from "../components/Card";

const API_KEY = process.env.REACT_APP_API_KEY;
const API_URL = `https://api.themoviedb.org/3/person/popular?api_key=${API_KEY}&language=en-US&page=1`;

const ActorsList = () => {
  const [actors, setActors] = useState([]);

  useEffect(() => {
    fetch(API_URL)
      .then((response) => response.json())
      .then((data) => {
        setActors(
          data.results.map((actor) => ({
            name: actor.name,
            image: actor.profile_path
              ? `https://image.tmdb.org/t/p/w500${actor.profile_path}`
              : "https://via.placeholder.com/300",
          }))
        );
      })
      .catch((error) => console.error("Error fetching actors:", error));
  }, []);

  return (
    <Container>
      <Typography
        variant="h3"
        align="center"
        gutterBottom
        sx={{ padding: "25px" }}
      >
        Actors
      </Typography>
      <Grid container spacing={3} justifyContent="center">
        {actors.map((actor, index) => (
          <Grid item key={index} xs={12} sm={6} md={4} lg={3}>
            <Cart text={actor.name} image={actor.image} />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default ActorsList;
